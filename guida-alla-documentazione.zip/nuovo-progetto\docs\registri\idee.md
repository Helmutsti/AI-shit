# Registro idee

<!-- Parte B della guida. Si aggiunge, non si cancella. -->

**Stati:** Proposta → In valutazione → Accettata → In progettazione → Pronta → Implementata · oppure Parcheggiata / Rifiutata

| Codice | Idea | Proposta da | Data | Stato | Posizione | Esito |
|---|---|---|---|---|---|---|
| ID-01 | Descrizione breve | Nome | gg/mm/aaaa | Proposta | — | — |
