# [Nome progetto]

[Slogan in una riga.]

[Cos'è il progetto, a cosa serve e per chi, in due o tre frasi.]

## Avvio rapido
```bash
# Installazione
[comando]

# Avvio in locale
[comando]

# Test
[comando]
```

## Documentazione
La documentazione del progetto si trova in [`docs/`](docs/) e segue il metodo descritto in [`docs/guida-documentazione.md`](docs/guida-documentazione.md).

- **Visione e requisiti generali:** [`docs/generale/`](docs/generale/)
- **Moduli:** [`docs/moduli/`](docs/moduli/)
- **Design system:** [`docs/design-system/`](docs/design-system/)
- **Architettura e ambienti:** [`docs/architettura/`](docs/architettura/)
- **Idee, decisioni e storico:** [`docs/registri/`](docs/registri/)

## Contribuire
Leggi [`CONTRIBUTING.md`](CONTRIBUTING.md). Se usi un agente IA, le sue istruzioni sono in [`AGENTS.md`](AGENTS.md).

## Note di rilascio
Vedi [`CHANGELOG.md`](CHANGELOG.md).
