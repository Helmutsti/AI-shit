# Glossario

<!-- Fase 1 della guida. Un termine, un significato, condiviso da tutti. -->

| Termine | Significato | Da non confondere con |
|---|---|---|
| | | |
