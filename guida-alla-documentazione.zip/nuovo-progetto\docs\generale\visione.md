# Visione

<!-- Fase 1 della guida. Si compila all'inizio del progetto. -->

**[Nome progetto]** – [Slogan in una riga.]

## Problema e contesto
Qual è il problema attuale? Come lo si risolve oggi, anche male?

[Da compilare]

## Visione
Una frase che descrive il futuro che il prodotto rende possibile.

[Da compilare]

## Obiettivi
Misurabili quando possibile.

| Obiettivo | Come si misura | Valore attuale | Valore atteso |
|---|---|---|---|
| | | | |

## Vincoli
Budget, tempi, tecnologie imposte, integrazioni obbligatorie.

- [Da compilare]

## Assunzioni
Ciò che si dà per vero senza averlo verificato. Ogni assunzione è un rischio.

- [Da compilare]

## Fuori dal progetto
Le esclusioni sono descritte nel registro idee (`docs/registri/idee.md`). Qui si elencano solo i codici.

- Parcheggiate: 
- Rifiutate: 
