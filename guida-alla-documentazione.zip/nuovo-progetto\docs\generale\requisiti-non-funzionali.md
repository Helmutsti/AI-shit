# Requisiti non funzionali

<!-- Fase 1 della guida. -->

| Codice | Categoria | Requisito | Come si verifica |
|---|---|---|---|
| RNF-01 | Prestazioni | | |
| RNF-02 | Sicurezza | | |
| RNF-03 | Privacy/GDPR | | |
| RNF-04 | Accessibilità | | |
| RNF-05 | Lingue | | |
| RNF-06 | Dispositivi e browser | | |
| RNF-07 | Disponibilità | | |
| RNF-08 | Usabilità | | |
