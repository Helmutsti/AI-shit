# Destinatari

<!-- Fase 1 della guida. -->

[Chi sono i destinatari, il loro livello di competenza digitale, i dispositivi usati e il contesto d'uso.]

## Ruoli
I ruoli determinano permessi e schermate.

| Ruolo | Descrizione | Cosa può fare |
|---|---|---|
| | | |

## Personas
2–3 profili sintetici di persone reali che useranno il prodotto.

### [Nome] – [Ruolo]
- **Chi è:** 
- **Competenza digitale:** bassa | media | alta
- **Dispositivi:** 
- **Contesto d'uso:** 
- **Bisogni:** 
- **Frustrazioni:** 
