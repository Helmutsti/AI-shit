# Storico

<!-- Parte B della guida. Una riga per ogni modifica alla fotografia. Le correzioni minori non si registrano. -->

| Data | Autore | Cosa è cambiato | Perché |
|---|---|---|---|
| gg/mm/aaaa | Nome | Aggiunto RF-00 | DEC-00 |
